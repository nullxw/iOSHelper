//
//  TakePhotoVC.h
//  KoalaPhoto
//
//  Created by 张英堂 on 14/11/13.
//  Copyright (c) 2014年 visionhacker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TakePhotoVC : UIViewController

@end
